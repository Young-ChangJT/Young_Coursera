/* Aoursera C Programming - Week 1 Assignment

**Author**: Chang Jih-Teng  
**Description**: This project performs statistical analysis on an array of unsigned char data.

